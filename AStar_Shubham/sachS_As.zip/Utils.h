#ifndef __UTILS_H__
#define __UTILS_H__

float RoundToNearestHalf(float num);
#endif // !__UTILS_H__

